﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
 defined('_JEXEC') or die();

 $document = JFactory::getDocument();
 $document->addScript('modules/mod_tablemakerforcsv/tmpl/js/jquery.dataTables.min.js');
 $script="$(document).ready(function () {
  $('.csvtable".$moduleclass_sfx."').DataTable({
    'pagingType': 'simple' 
  });
  $('.dataTables_length').addClass('bs-select');
});";
 $document->addCustomTag( '<script type="text/javascript">'.$script.'</script>' );

$style=".csvtable".$moduleclass_sfx."{
    text-align:".$textalign.";
    font:".$tablefont.";
    border-radius:".$borderradius.";
    ".$table_style."
}
.csvtable".$moduleclass_sfx." td{
padding:".$padding.";
}
.csvtable".$moduleclass_sfx." tr:nth-child(even) td{
    background: ".$evenbg.";
}
.csvtable".$moduleclass_sfx." tr:nth-child(odd) td{
    background: ".$oddbg.";
}
.csvtable".$moduleclass_sfx." tr:first-child  td{
background:".$firstrow_bg.";
color:".$firstrow_color.";
font:".$firstrow_font.";
}
";
$document->addStyleDeclaration($style);
 if(trim($pretext)!="")
 {
 echo '<div class="pretext">'.$pretext.'</div>';
 }
 if($fileurl!="")
 {
  $file = fopen('images/'.$fileurl,"r");
 echo '<table class="csvtable'.$moduleclass_sfx.'">';
 if(trim($captions)!="")
 {
  echo '<tr>';
   for($i=0;$i<count($caption);$i++)
  {
   echo '<th>'.$caption[$i].'</th>';
  }
   echo '</tr>';

 }
 echo '<tbody>';
while($f=fgetcsv($file))
{  // $f = array_map("utf8_encode", $f);

echo '<tr>';
for($i=0;$i<count($f);$i++)
{
   echo '<td>'.$f[$i].'</td>';
}
echo '</tr>';
}
echo '</tbody>';
echo '</table>';
fclose($file);
}
 if(trim($posttext)!="")
 {
 echo '<div class="posttext">'.$posttext.'</div>';
 }