﻿<?php
/**
* @Author  Mostafa Shahiri
*@license	GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
defined('_JEXEC') or die();

// Include the helper class

jimport( 'joomla.application.module.helper' );

$fileurl=$params->get('fileurl');
$separator=$params->get('separator');
$min_char=$params->get('min_char');
$captions=$params->get('caption');
$table_style=$params->get('table_style');
$pretext=$params->get('pretext');
$posttext=$params->get('posttext');
$textalign=$params->get('table_text_align');
$tablefont=$params->get('table_font');    
$borderradius=$params->get('table_border_radius');
$padding=$params->get('table_padding');
$evenbg=$params->get('even_bg');
$oddbg=$params->get('odd_bg');
$firstrow_bg=$params->get('firstrow_bg');
$firstrow_color=$params->get('firstrow_color');
$firstrow_font=$params->get('firstrow_font');
$row_num=intval($params->get('row_num'));
$pagalign=$params->get('pagalign');
$paglink_bg=$params->get('paglink_bg');
$paglink_color=$params->get('paglink_color');
$paglink_active=$params->get('paglink_active');
$paglink_hoverbg=$params->get('paglink_hoverbg');
$paglink_hovercolor=$params->get('paglink_hovercolor');
$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx')); 
 if(trim($captions)!="")
 {
 $caption=explode('@#',$captions);
 }


// Display the template
require(JModuleHelper::getLayoutPath('mod_tablemakerforcsv'));

?>